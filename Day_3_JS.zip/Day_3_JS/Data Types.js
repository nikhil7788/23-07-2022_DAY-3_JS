
var Num=50;
var Str=" Royal Banna ";
var BooleanVar=true;

document.write("<br/>",Num);
document.write("<br/>",Str);
document.write("<br/>",BooleanVar);

document.write("<br/>",typeof(BooleanVar));

var obj=new Object();
document.write("<br/>",typeof(obj));
document.write("<br/>",+obj.Firstname+" "+obj.Lastname);

var Bike = {
    modal: "Splendor",
    color: "Black",
    price: "49500-74400"
}
document.write("<br/>"+Bike.modal+" "+Bike.color+" "+Bike.price);

var cars = ["Audi", "Ferrari", "Bugatti"];
document.write("<br/>"+cars[0]);
document.write("<br/>"+cars[1]);
document.write("<br/>"+cars[2]);



var Nik = function(){ 
    return "Hello World!"; 
}
document.write("<br/>"+typeof(Nik));
document.write("<br/>"+Nik());